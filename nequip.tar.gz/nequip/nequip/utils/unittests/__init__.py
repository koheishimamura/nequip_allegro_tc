import pathlib

CONFTEST_PATH = pathlib.Path(__file__).parent / "conftest.py"
