YAML input
==========

TODO
