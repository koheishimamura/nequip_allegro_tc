Conventions
===========

 - Cells vectors are given in ASE style as the **rows** of the cell matrix
 - The first index in an edge tuple (``edge_index[0]``) is the center atom, and the second (``edge_index[1]``) is the neighbor