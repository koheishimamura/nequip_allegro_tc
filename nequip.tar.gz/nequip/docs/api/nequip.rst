Python API
==========

 .. toctree::

    data
    trainer
