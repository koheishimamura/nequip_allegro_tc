FAQ
===

How do I...
-----------

... continue to train a model that reached a stopping condition?
    There will be an answer here.

1. Reload the model trained with version 0.3.3 to the code in 0.4.
   check out the migration note at :ref:`migration_note`.

2. Specify my dataset for `nequip-train` and `nequip-eval`, see :ref:`_dataset_note`.

